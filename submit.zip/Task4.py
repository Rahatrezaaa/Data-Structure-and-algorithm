"""
Read file into texts and calls.
It's ok if you don't understand how to read files.
"""
import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

"""
TASK 4:
The telephone company want to identify numbers that might be doing
telephone marketing. Create a set of possible telemarketers:
these are numbers that make outgoing calls but never send texts,
receive texts or receive incoming calls.

Print a message:
"These numbers could be telemarketers: "
<list of numbers>
The list of numbers should be print out one per line in lexicographic order with no duplicates.
"""
outgoing_call_numbers=[a[0] for a in calls]
incoming_call_numbers=[a[1] for a in calls]
incoming_msg_numbers=[a[1] for a in texts]
outgoing_msg_numbers=[a[0] for a in texts]

#removing the undesired numbers from outgoing_call numbers
telemarketersNumbers=set(outgoing_call_numbers)-set(incoming_call_numbers)-set(incoming_msg_numbers)-set(outgoing_msg_numbers)

#Convert To Set to earse Duplicates
telemarketersNumbers = sorted(list(telemarketersNumbers))


#Printing

print("These numbers could be telemarketers: ")
for i in range(len(telemarketersNumbers)):
    print(telemarketersNumbers[i] )
